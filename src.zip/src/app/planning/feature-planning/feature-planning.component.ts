import {Component} from '@angular/core';

@Component({
  template: `<div>Feature component works and activated!</div>`,
})
export class FeaturePlanningComponent {}
