export class UserLogin {

  constructor(
    public age: number,
    public name: string,
    public password: string,
    public login: string
  ) {  }

}
